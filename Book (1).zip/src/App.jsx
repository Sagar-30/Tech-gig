import './App.css'

export default function App() {
  return (
    <main>
      React  + Vite ⚡ + Replit 🌀
    </main>
  )
}
