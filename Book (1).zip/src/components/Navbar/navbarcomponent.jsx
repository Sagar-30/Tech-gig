import {Person, List ,XLg ,TelephoneFill } from 'react-bootstrap-icons';
import {  EnvelopeFill , Facebook ,Instagram, Twitter, Github} from 'react-bootstrap-icons';
import {BrowserRouter , Link ,Routes , Route, Outlet } from 'react-router-dom'
import {useState} from 'react';
import "./navbarcomponent.css";
import MainHome from '../../Modules/Home/mainhomemodule.jsx'
// import Rentmodule from '../../Modules/Rent/rentmodule.jsx';

export default function Navbar(){
  const [clicked, setclicked] = useState(false);
  function HandleNavbarClick(){
      setclicked(!clicked);
  }
    return(
      <>
        <section className="navbar-section-main">
            <div className="navbar-icon-div">
                  <p><b>Just rent it</b></p>
            </div>
            <div className="navber-links-div">
                <BrowserRouter>
                  <Routes>
                  <Route path="/home" element={<MainHome />} > </Route>
                  </Routes>
                <ul>
                    <li><Link to="/home">Home</Link></li>
                    <li><Link to="/about">About</Link></li>
                    <li><Link to="/rent">Rent</Link></li>
                    <li><Link to="/contact">Contact Us</Link></li>
                    <li><Link to="/login">{<Person />}</Link></li>
                </ul>
                  
                </BrowserRouter>
                 
            </div>
             <span className='Navbar-hamburger-div'> <List style={{height:'2rem', width:'50px',margin:'0 2rem'}} className='Navbar-hamburger' onClick={HandleNavbarClick} /></span>
        </section>
              <section className='responsive-navbar-main' style={{display: clicked ? 'none' : 'unset'}} >
                <div className='responsive-navbar-main-box'>
                  <div className='responsive-navbar-icon-div'>
                    <span><XLg onClick={HandleNavbarClick} /></span>
                    </div>
                  <div className='responsive-navbar-links-div'>
                    <BrowserRouter>
                    <ul>
                        <li><Link to="/home">Home</Link></li>
                        <li><Link to="/about">About</Link></li>
                        <li><Link to="/rent">Rent</Link></li>
                        <li><Link to="/contact">Contact Us</Link></li>
                        <li><Link to="/login">{<Person />}</Link></li>
                    </ul>
                    </BrowserRouter>
                    </div>
                  <div className='responsive-navbar-contact-div'>
                    <div className='responsive-navbar-contact-text'>
                      <p>Get in touch</p>
                    </div>
                    <div className="responsive-navbar-contact-icons">
                      <p>{<TelephoneFill />}  Call us on - +919350572047</p>
                      <p>{<EnvelopeFill />}  Email : sagar302001@gmail.com</p>
                      </div>
                  </div>
                </div>
              </section>
        </>
    )
}
